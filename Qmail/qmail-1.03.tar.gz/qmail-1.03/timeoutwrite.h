#ifndef TIMEOUTWRITE_H
#define TIMEOUTWRITE_H

extern int timeoutwrite();

#endif
