#ifndef EXTRA_H
#define EXTRA_H

#define QUEUE_EXTRA ""
#define QUEUE_EXTRALEN 0

#endif
