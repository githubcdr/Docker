#ifndef QSUTIL_H
#define QSUTIL_H

extern void log1();
extern void log2();
extern void log3();
extern void logsa();
extern void nomem();
extern void pausedir();
extern void logsafe();

#endif
