#ifndef MYCTIME_H
#define MYCTIME_H

extern char *myctime();

#endif
