#ifndef AUTO_SPAWN_H
#define AUTO_SPAWN_H

extern int auto_spawn;

#endif
