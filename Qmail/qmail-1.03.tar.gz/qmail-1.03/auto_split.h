#ifndef AUTO_SPLIT_H
#define AUTO_SPLIT_H

extern int auto_split;

#endif
