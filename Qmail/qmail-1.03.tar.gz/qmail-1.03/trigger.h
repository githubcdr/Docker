#ifndef TRIGGER_H
#define TRIGGER_H

extern void trigger_set();
extern void trigger_selprep();
extern int trigger_pulled();

#endif
