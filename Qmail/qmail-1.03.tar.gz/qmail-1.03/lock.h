#ifndef LOCK_H
#define LOCK_H

extern int lock_ex();
extern int lock_un();
extern int lock_exnb();

#endif
