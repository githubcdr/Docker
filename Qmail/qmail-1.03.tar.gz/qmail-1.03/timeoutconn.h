#ifndef TIMEOUTCONN_H
#define TIMEOUTCONN_H

extern int timeoutconn();

#endif
