int RAWGET_get( unsigned char *buffer, int max, FILE *f );

