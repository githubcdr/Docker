#ifndef __BYTEDECODERS__
#define __BYTEDECODERS__

int get_int8( char *start );
int get_int16( char *start );
int get_int32( char *start );

unsigned int get_uint8( char *start );
unsigned int get_uint16( char *start );
unsigned int get_uint32( char *start );

#endif

