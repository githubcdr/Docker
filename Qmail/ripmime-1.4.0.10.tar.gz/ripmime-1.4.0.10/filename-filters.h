int FNFILTER_init( void );
int FNFILTER_set_debug( int level );
int FNFILTER_set_verbose( int level );
int FNFILTER_set_paranoid( int level );
int FNFILTER_set_mac( int level );
int FNFILTER_filter( char *fname, int size );

