#ifndef OPEN_H
#define OPEN_H

extern int open_read(char *);
extern int open_excl(char *);
extern int open_append(char *);
extern int open_trunc(char *);
extern int open_write(char *);

#endif
